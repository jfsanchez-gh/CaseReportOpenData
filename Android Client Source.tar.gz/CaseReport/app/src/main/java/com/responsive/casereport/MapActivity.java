package com.responsive.casereport;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;


public class MapActivity extends AppCompatActivity {


    private static final String SERVER_URL = "http://10.53.1.163:8000/";
//        private static final String SERVER_URL = "http://humanos.uci.cu/";
    private static final String MAP_CHART = "charts/main";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        TextView title = (TextView) findViewById(R.id.title);
        String url = getIntent().getExtras().getString("URL");

        if (url.equals("/")){
            title.setText(getString(R.string.world_title));
        }else if (url.equals("/Z/")){
            title.setText(getString(R.string.zika_title));
        }else if (url.equals("/D/")){
            title.setText(getString(R.string.dengue_title));
        }else if (url.equals("/C/")){
            title.setText(getString(R.string.chikungunya_title));
        }

        Log.e("MY_DEBUG", url);


        final ProgressBar pb = (ProgressBar) findViewById(R.id.pb);
        final WebView web = (WebView) findViewById(R.id.web);

        web.getSettings().setJavaScriptEnabled(true);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                pb.setVisibility(View.GONE);
                web.setVisibility(View.VISIBLE);
                super.onPageFinished(view, url);
            }

        });
//        web.loadData(Global.html, "text/html; charset=UTF-8", null);
        web.loadUrl(SERVER_URL + MAP_CHART + url);
    }

}
