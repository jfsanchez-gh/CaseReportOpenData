package com.responsive.casereport.data;

/**
 * Created by Ingo on 19.07.2015.
 */
public interface Chargable {

    double getPrice();

}
