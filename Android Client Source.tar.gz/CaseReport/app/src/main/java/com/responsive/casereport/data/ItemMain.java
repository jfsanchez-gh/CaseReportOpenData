package com.responsive.casereport.data;

/**
 * Created by koyi on 6/05/16.
 */
public class ItemMain {

    private String color;
    private String title;
    private String content;
    private String url;

    public ItemMain(String color, String title, String content, String url) {
        this.color = color;
        this.title = title;
        this.content = content;
        this.url = url;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    @Override
    public String toString() {
        return "ItemMain{" +
                "color='" + color + '\'' +
                ", title='" + title + '\'' +
                ", content='" + content + '\'' +
                '}';
    }
}
