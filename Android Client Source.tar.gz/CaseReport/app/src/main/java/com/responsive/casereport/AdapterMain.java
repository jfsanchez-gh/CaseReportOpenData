package com.responsive.casereport;

/**
 * Created by koyi on 6/05/16.
 */

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.responsive.casereport.data.ItemMain;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by koyi on 2/12/15.
 */
public class AdapterMain extends RecyclerView.Adapter<AdapterMain.MainViewHolder> {
    private List<ItemMain> items;
    private Context context;

    public AdapterMain(ArrayList<ItemMain> items, Context context) {
        this.items = items;
        this.context = context;
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    @Override
    public MainViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.card_main, viewGroup, false);
        return new MainViewHolder(v);
    }

    @Override
    public void onBindViewHolder(final MainViewHolder viewHolder, final int i) {
        final int ii = i;
        viewHolder.layout.setBackgroundColor(Color.parseColor(items.get(i).getColor()));
        viewHolder.title.setText(items.get(i).getTitle());
        viewHolder.content.setText(items.get(i).getContent());


        viewHolder.btn_map.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle b = new Bundle();
                b.putString("URL", items.get(i).getUrl());
                Intent intent = new Intent(context, MapActivity.class);
                intent.putExtras(b);
                context.startActivity(intent);
            }
        });
        viewHolder.btn_chart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle b = new Bundle();
                b.putString("URL", items.get(i).getUrl());
                Intent intent = new Intent(context, ChartActivity.class);
                intent.putExtras(b);
                context.startActivity(intent);
            }
        });
    }

    public static class MainViewHolder extends RecyclerView.ViewHolder {
        // Campos respectivos de un item

        public CardView card;
        public RelativeLayout layout;
        public TextView title;
        public TextView content;
        public Button btn_map;
        public Button btn_chart;

        public MainViewHolder(View v) {
            super(v);

            card = (CardView) v.findViewById(R.id.cardView);
            layout = (RelativeLayout) v.findViewById(R.id.header);
            title = (TextView) v.findViewById(R.id.itemTitle);
            content = (TextView) v.findViewById(R.id.itemContent);
            btn_chart = (Button) v.findViewById(R.id.btn_chart);
            btn_map = (Button) v.findViewById(R.id.btn_map);

        }
    }
}
