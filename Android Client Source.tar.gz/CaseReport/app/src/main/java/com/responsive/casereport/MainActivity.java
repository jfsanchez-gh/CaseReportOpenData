package com.responsive.casereport;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.goka.blurredgridmenu.GridMenu;
import com.goka.blurredgridmenu.GridMenuFragment;
import com.responsive.casereport.data.ItemMain;

import java.util.ArrayList;
import java.util.List;

import lecho.lib.hellocharts.listener.PieChartOnValueSelectListener;
import lecho.lib.hellocharts.model.PieChartData;
import lecho.lib.hellocharts.model.SliceValue;
import lecho.lib.hellocharts.view.PieChartView;

public class MainActivity extends AppCompatActivity {


    private GridMenuFragment mGridMenuFragment;

    private PieChartView pieChart;
    private PieChartData data;
    private boolean hasLabels = true;
    private boolean hasLabelsOutside = true;
    private boolean hasLabelForSelected = false;
    //Como ejemplo, en un examen tenemos buenas, malas y no respondidas.
    private int buenas = 0, malas = 0, noresp = 0, total = 0;

    private RecyclerView recycler;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager lManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
//                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mGridMenuFragment = GridMenuFragment.newInstance(R.drawable.back);

        final FrameLayout fl = (FrameLayout) findViewById(R.id.main_frame);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fl.setVisibility(View.VISIBLE);
                Log.e("MY_DEBUG", "okkkkkkkkk");
                FragmentTransaction tx = getSupportFragmentManager().beginTransaction();
                tx.replace(R.id.main_frame, mGridMenuFragment);
                tx.addToBackStack(null);
                tx.commit();
            }
        });

        setupGridMenu();

        mGridMenuFragment.setOnClickMenuListener(new GridMenuFragment.OnClickMenuListener() {
            @Override
            public void onClickMenu(GridMenu gridMenu, int position) {
                if (position == 0) {
                    Bundle b = new Bundle();
                    b.putString("URL", "/");
                    Intent intent = new Intent(MainActivity.this, MapActivity.class);
                    intent.putExtras(b);
                    startActivity(intent);
                } else if (position == 1) {
                    Intent intent = new Intent(MainActivity.this, TableActivity.class);
                    startActivity(intent);
                    fl.setVisibility(View.GONE);
                }
                Toast.makeText(MainActivity.this, "Title:" + gridMenu.getTitle() + ", Position:" + position,
                        Toast.LENGTH_SHORT).show();
            }
        });


        //Recycler-------------------------------------------------------

        ArrayList<ItemMain> items = new ArrayList<>();
        items.add(new ItemMain("#ff5722", "Zika", getString(R.string.zika_text), "/Z/"));
        items.add(new ItemMain("#ff9800", "Dengue", getString(R.string.dengue_text), "/D/"));
        items.add(new ItemMain("#ffc107", "Chikungunya", getString(R.string.chikungunya_text), "/C/"));

        //Obtener el Recycler
        recycler = (RecyclerView) findViewById(R.id.recycler);
        recycler.setHasFixedSize(true);

        // Usar un administrador para LinearLayout
        lManager = new LinearLayoutManager(this);
        recycler.setLayoutManager(lManager);

        // Crear un nuevo adaptador
        adapter = new AdapterMain(items, this);
        recycler.setAdapter(adapter);

        //Charts------------------------------------------------------------

//        pieChart = (PieChartView) findViewById(R.id.pieChart);
//
//        buenas = 5;
//        malas = 2;
//        noresp = 3;
//        total=buenas+malas+noresp;
//
//        pieChart.setOnValueTouchListener(new ValueTouchListener());
//        //toggleLabels();
//        generateDataPieChar();


    }

    private void setupGridMenu() {
        List<GridMenu> menus = new ArrayList<>();
        menus.add(new GridMenu("Home", R.drawable.home));
        menus.add(new GridMenu("Calendar", R.drawable.calendar));
        menus.add(new GridMenu("Overview", R.drawable.overview));
        menus.add(new GridMenu("Groups", R.drawable.groups));
        menus.add(new GridMenu("Lists", R.drawable.lists));
        menus.add(new GridMenu("Profile", R.drawable.profile));
        menus.add(new GridMenu("Timeline", R.drawable.timeline));
        menus.add(new GridMenu("Setting", R.drawable.settings));

        mGridMenuFragment.setupMenu(menus);
    }

    @Override
    public void onBackPressed() {
        if (0 == getSupportFragmentManager().getBackStackEntryCount()) {
            super.onBackPressed();
        } else {
            getSupportFragmentManager().popBackStack();
        }
    }

    public void resetCounts() {
        buenas = 0;
        malas = 0;
        noresp = 0;
    }

    private void generateDataPieChar() {
        int numValues = 3;    // Numero de particiones y/o variables
        List<SliceValue> values = new ArrayList<SliceValue>();
    /*Definimos el tamano (mediante un valor porcentual referente a cierta variable) y el color que tendra*/
        if (buenas > 0) {
            SliceValue sliceValueBuenas = new SliceValue((float) buenas * 100 / total, Color.BLUE);
            values.add(sliceValueBuenas);
        }
        if (malas > 0) {
            SliceValue sliceValueMalas = new SliceValue((float) malas * 100 / total, Color.CYAN);
            values.add(sliceValueMalas);
        }
        if (noresp > 0) {
            SliceValue sliceValueNulas = new SliceValue((float) noresp * 100 / total, Color.GREEN);
            values.add(sliceValueNulas);
        }

        data = new PieChartData(values);
        data.setHasLabels(true); // Muesta el valor de la particion (texto)
        data.setHasCenterCircle(true);
        data.setCenterCircleScale(0.5f);
        data.setCenterText1("My Graphic");
        data.setCenterText1FontSize(15);
        data.setCenterText2("Test");
        data.setCenterText2FontSize(10);

        data.setHasLabelsOnlyForSelected(false);
        data.setHasLabelsOutside(true);
        pieChart.setPieChartData(data);
        pieChart.setCircleFillRatio(0.8f);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            return true;
//        }

        return super.onOptionsItemSelected(item);
    }

    private class ValueTouchListener implements PieChartOnValueSelectListener {

        @Override
        public void onValueSelected(int arcIndex, SliceValue value) {
            Toast.makeText(MainActivity.this, value.getValue() + " %", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onValueDeselected() {
        }
    }
}
