package com.responsive.casereport;

/**
 * Created by koyi on 6/05/16.
 */
public class Global {
    public static String html;
}
