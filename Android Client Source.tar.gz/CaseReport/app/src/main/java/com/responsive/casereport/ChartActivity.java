package com.responsive.casereport;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import lecho.lib.hellocharts.listener.PieChartOnValueSelectListener;
import lecho.lib.hellocharts.model.Axis;
import lecho.lib.hellocharts.model.Column;
import lecho.lib.hellocharts.model.ColumnChartData;
import lecho.lib.hellocharts.model.PieChartData;
import lecho.lib.hellocharts.model.SliceValue;
import lecho.lib.hellocharts.model.SubcolumnValue;
import lecho.lib.hellocharts.util.ChartUtils;
import lecho.lib.hellocharts.view.ColumnChartView;
import lecho.lib.hellocharts.view.PieChartView;

public class ChartActivity extends AppCompatActivity {

    private PieChartView pieChart;
    private PieChartData data;
    private ColumnChartView columnChart;
    private ColumnChartData columnData;
    private boolean hasLabels = true;
    private boolean hasLabelsOutside = true;
    private boolean hasLabelForSelected = false;
    //Como ejemplo, en un examen tenemos buenas, malas y no respondidas.
    private int kid = 0, teenager = 0, adult = 0, old = 0, total = 0;
    private int dead = 65, alive = 742;
    private String title;

    private class ValueTouchListener implements PieChartOnValueSelectListener {

        @Override
        public void onValueSelected(int arcIndex, SliceValue value) {
            Toast.makeText(ChartActivity.this, value.getValue() + " %", Toast.LENGTH_SHORT).show();
        }

        @Override
        public void onValueDeselected() {
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        TextView title1 = (TextView) findViewById(R.id.itemTitle);
        TextView title2 = (TextView) findViewById(R.id.itemTitle1);
        String url = getIntent().getExtras().getString("URL");

        if (url.equals("/")){
            title = getString(R.string.world_title);
        }else if (url.equals("/Z/")){
            title = getString(R.string.zika_title);
        }else if (url.equals("/D/")){
            title = getString(R.string.dengue_title);
        }else if (url.equals("/C/")){
            title = getString(R.string.chikungunya_title);
        }

        title1.setText(title + " - " + getString(R.string.cases_by_age));
        title2.setText(title + " - " + getString(R.string.cases_of_dead));
        columnChart();
        pieChart();


    }

    public void columnChart(){
        //Grafico de barra (ColunmChartView)
        int numSubcolumns = 1;
        int numColumns = 1;
        // Column can have many subcolumns, here by default I use 1 subcolumn in each of 8 columns.
        List<Column> columns = new ArrayList<Column>();
        List<SubcolumnValue> valuess;
        for (int i = 0; i < numColumns; ++i) {

            valuess = new ArrayList<SubcolumnValue>();
//            for (int j = 0; j < numSubcolumns; ++j) {
//                valuess.add(new SubcolumnValue((float) Math.random() * 50f + 5, ChartUtils.pickColor()));
//            }

            valuess.add(new SubcolumnValue((float) 25, ContextCompat.getColor(this, R.color.colorKid)));
            valuess.add(new SubcolumnValue((float) 54, ContextCompat.getColor(this, R.color.colorTeenager)));
            valuess.add(new SubcolumnValue((float) 10, ContextCompat.getColor(this, R.color.colorAdult)));
            valuess.add(new SubcolumnValue((float) 60, ContextCompat.getColor(this, R.color.colorOld)));

            Column column = new Column(valuess);
            column.setHasLabels(hasLabels);
            column.setHasLabelsOnlyForSelected(hasLabelForSelected);
            columns.add(column);
        }

        columnData = new ColumnChartData(columns);

        if (true) { //hasAxes
            Axis axisX = new Axis();
            Axis axisY = new Axis().setHasLines(true);
            if (true) { //hasAxesNames
                axisX.setName("Axis X");
                axisY.setName("Amount");
            }
//            columnData.setAxisXBottom(axisX);
            columnData.setAxisYLeft(axisY);
        } else {
            columnData.setAxisXBottom(null);
            columnData.setAxisYLeft(null);
        }
        columnChart = (ColumnChartView)findViewById(R.id.columnchart);
        columnChart.setColumnChartData(columnData);
    }

    public void pieChart(){
        //Grafico de pastel (PieChartView)
        pieChart = (PieChartView) findViewById(R.id.pieChart);

        dead = 65;
        alive = 742;

        pieChart.setOnValueTouchListener(new ValueTouchListener());
        //toggleLabels();
        generateDataPieChar();
    }



    private void generateDataPieChar() {
        List<SliceValue> values = new ArrayList<>();
	/*Definimos el tamano (mediante un valor porcentual referente a cierta variable) y el color que tendra*/
        if (dead > 0) {
            SliceValue sliceValueBuenas = new SliceValue((float) dead, ContextCompat.getColor(this, R.color.colorDead));
            values.add(sliceValueBuenas);
        }
        if (alive > 0) {
            SliceValue sliceValueMalas = new SliceValue((float) alive , ContextCompat.getColor(this, R.color.colorAlive));
            values.add(sliceValueMalas);
        }

        data = new PieChartData(values);
        data.setHasLabels(true); // Muesta el valor de la particion (texto)
        data.setHasCenterCircle(true);
        data.setCenterCircleScale(0.5f);
        data.setCenterText1(getString(R.string.cases_of_dead));
        data.setCenterText1FontSize(15);
        data.setCenterText2(title);
        data.setCenterText2FontSize(10);

        data.setHasLabelsOnlyForSelected(false);
        data.setHasLabelsOutside(true);
        pieChart.setPieChartData(data);
        pieChart.setCircleFillRatio(0.8f);
    }

}
